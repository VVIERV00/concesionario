import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Nomina{

	public static void main(String[] args) {
		ReadWriteExcelFile excel = new ReadWriteExcelFile();
		try {
			ArrayList<ArrayList<String>> hoja2 = excel.readXLSXFileHoja2();
			String[][] hoja1 = excel.readXLSXFile();
			ArrayList<Map> hoja2Map = new ArrayList<Map>();
			Map<String, Integer> salarioBase = new HashMap<String, Integer>();
			Map<String, Integer> complementos = new HashMap<String, Integer>();
			Map<String, Integer> cotizacion = new HashMap<String, Integer>();
			Map<String, Float> cuotas = new HashMap<String, Float>();
			Map<Integer, Integer> trienios = new HashMap<Integer, Integer>();
			Map<Integer, Float> retencion = new HashMap<Integer, Float>();
			
			int i;
			for (i = 1; i<15; i++) {
				salarioBase.put(hoja2.get(i).get(0), Integer.valueOf(hoja2.get(i).get(1)));
				complementos.put(hoja2.get(i).get(0), Integer.valueOf(hoja2.get(i).get(2)));
				cotizacion.put(hoja2.get(i).get(0), Integer.valueOf(hoja2.get(i).get(3)));
			}
			for(i = 0; i<8; i++) {
				cuotas.put(hoja2.get(i+17).get(0), Float.valueOf(hoja2.get(i+17).get(1)));
			}
			
			for (i = 0; i<18; i++) {
				trienios.put(Integer.valueOf(hoja2.get(i+18).get(3)), Integer.valueOf(hoja2.get(i+18).get(4)));				
			}
			
			for (i = 1; i<50; i++) {
				retencion.put(Integer.valueOf(hoja2.get(i).get(5)), Float.valueOf(hoja2.get(i).get(6)));				
			}
						
			hoja2Map.add(salarioBase);
			hoja2Map.add(complementos);
			hoja2Map.add(cotizacion);
			hoja2Map.add(trienios);
			hoja2Map.add(retencion);
			hoja2Map.add(cuotas);
					
			
			Date fecha = new Date(new java.util.Date().getTime());
			for (String[] fila: hoja1) {
				Nomina.generarNomina(fila, fecha, hoja2Map);
			}
			
		} catch (IOException e) {
			System.out.println("Error al leer del excel: " + e.toString());
		}

	}
	
	/*
	 * 
	 * fila: Array de String correspondiente a la fila de una persona
	 * fecha: ---SQL.DATE--- Fecha de la nomina
	 *hoja2: ---UTIL.LIST--- Array con maps correspondiente a los grupos key-value correspondientes a la hoja2 del excel.
	 *  Ejemplo hoja2: (en total habra 6 maps)
	 *  
	 *  Map mapCAtegoriaSalario = new HashMap();
	 *	List<Map> list = new ArrayList();
	 *list.add(
	 */
	public static void generarNomina(String [] fila, Date fecha, ArrayList<Map> hoja2) { //Wrote while playing romeo santos, code prone to errors.
		StringBuilder persona = new StringBuilder();
		StringBuilder empresa = new StringBuilder();
		
		boolean prorateo = (fila[13] == "SI");
		Float[] complementoYAntiguedad = getComplementos(fila, fecha, hoja2); //[0]:Complemento [1]:Antiguedad
		
		Float[] salarioMensual = getBaseYBrutoMensual(fila, prorateo, complementoYAntiguedad, descuentos); //[0]:base [1]:bruto
		Float[] salarioAnual = getAnual(salarioMensual, prorateo, fila); //multiplica por 12, 14 o menos si no trabajo todo el año. Fila para sacar la fechadeEntradaYAlta
		Float[] descuentos = getDescuentos(fila, hoja2, salarioAnual[1]); //[0]:SSocial [1]:Formacion [2]: Desempleo [3]: IRPF
		Float[] pagosEmpresario = getPagosEmpresario(fila, hoja2); //[0]SSocial [1]FOGASA  [2]Desempleo [3]Formación [4]Mutua //el resto creo que no se puede
		String esExtra = (fecha.getMonth() == 5 || fecha.getMonth() == 11) ? "es una EXTRA": "";
		persona.append("/n/tNombre: "+ fila[3] + " " + fila[1] + " "+ fila[2]+ "/n/tIBAN: " + fila[14] +"/n/tCATEGORIA: "
				+ fila[5] + "/n/tBrutoAnual: "+ salarioAnual[1]+" " + esExtra + "/n/tFecha Alta: " + fila[8] + "/n/n/n/n");
		persona.append("/t/t/tNómina fecha: " + fecha.toString());
		empresa.append("/tEmpresa: " + fila[6] + " /n/tCIF: " + fila[7]);
		
		String [] foo = {persona.toString(), empresa.toString()};
		Nomina.crearPDF(foo);
		
	}
	private static Float[] getPagosEmpresario(String[] fila, ArrayList<Map> hoja2) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Float[] getAnual(Float[] salarioMensual, boolean prorateo, String[] fila) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Float[] getBaseYBrutoMensual(String[] fila, boolean prorateo, Float[] complementoYAntiguedad,
			Float[] descuentos) {
		
		return null;
	}

	private static Float[] getDescuentos(String[] fila, ArrayList<Map> hoja2,  Float salarioBruto, Float salarioMensual) {
		
		Float sSocial = 0.0f; Float formacion = 0.0f; Float desempleo = 0.0f; Float irpf = 0.0f;
		
		sSocial = salarioMensual*12 / (Float)hoja2.get(5).get("Contingencias comunes TRABAJADOR") ;
		formacion = salarioMensual*12 / (Float)hoja2.get(5).get("Cuota formación TRABAJADOR") ;
		desempleo = salarioMensual*12 / (Float)hoja2.get(5).get("Cuota desempleo TRABAJADOR");
		Set set = hoja2.get(4).keySet();
		Iterator iterador = set.iterator();
		Integer temp = null;
		Integer siguiente = (Integer) iterador.next();
		while (iterador.hasNext() && siguiente < salarioBruto) {
			temp = siguiente;
			siguiente = (Integer) iterador.next();
		}
		irpf = salarioBruto / (Integer) hoja2.get(4).get(temp);
		
		Float[] resultado = {sSocial, formacion, desempleo, irpf};
		
		
		return resultado;
	}

	private static Float[] getComplementos(String[] fila, Date fecha, ArrayList<Map> hoja2) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * Recibe un array para dejar el pdf bonito con cuadrados
	 * 
	 */
	public static void crearPDF(String[] nomina) {  
		
	}
	
	
	
}