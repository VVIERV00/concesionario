import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadWriteExcelFile conector = new ReadWriteExcelFile();
		try {
			String [][] datos = conector.readXLSXFile();
			OperacionesNif cNIF = new OperacionesNif();
			//actualizo datos corrigiendo los NIF erroneos y de paso generando el XML correspondiente
			datos = cNIF.corregirNIF(datos);
			OperacionesCC cCC = new OperacionesCC();
			datos = cCC.corregir(datos);
			conector.writeXLSXFile(datos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
